﻿internal class Program
{
    private static void Main (string[] args){

  sola sola = new sola();
  sola.hghs();
    }
}
