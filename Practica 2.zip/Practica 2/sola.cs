class sola{
public void hghs (){
Console.WriteLine("HOLA WAPO");
Console.ReadKey();

}
}
